import React from 'react'

export default function About() {
  return (
    <section className='my-9 flex flex-col gap-4  '>
        <h1 className="text-4xl font-bold ">About This Event</h1>
        <p>Nisi esse proident ipsum culpa deserunt qui minim ut aute sunt occaecat. Consequat occaecat nostrud eiusmod culpa deserunt elit incididunt reprehenderit id aliqua duis adipisicing. Exercitation anim sit adipisicing aute magna laboris ea ad. Irure sunt Lorem veniam aliquip adipisicing excepteur dolor est ullamco consequat consectetur commodo elit adipisicing. Ullamco ad incididunt minim elit irure labore proident eiusmod reprehenderit pariatur tempor occaecat.nostrud aliqua esse est qui mollit occaecat. Consequat pariatur aliqua cillum ea irure reprehenderit do magna id. Pariatur fugiat ipsum nisi incididunt laborum aute consectetur esse commodo. Laborum ea ipsum veniam consectetur laboris. Officia aliqua non ut amet fugiat et nisi culpa. Deserunt aliqua quis duis tempor pariatur duis.</p>
    </section>
  )
}
