import React from 'react'

export default function EventPage() {
  return (
    <div>Event</div>
  )
}
