import React from 'react'

export default function UpcomingEvents() {
  return (
    <section className='flex justify-center min-h-[10rem] my-24'>
        <div className='w-[90%]'>
        <h1 className='text-5xl font-bold'>
        Upcoming Events in Sydney
        </h1>
        </div>
    </section>
  )
}
